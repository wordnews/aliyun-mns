<?php

include __DIR__ . '/Tests/ClientTest.php';

$ClientTest = new ClientTest();

$re = $ClientTest->testCreateQueueAsync();
var_dump($re);







