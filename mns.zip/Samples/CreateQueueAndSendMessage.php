<?php
require_once(dirname(dirname(__FILE__)).'/mns-autoloader.php');

use AliyunMNS\Client;
use AliyunMNS\Requests\SendMessageRequest;
use AliyunMNS\Requests\CreateQueueRequest;
use AliyunMNS\Exception\MnsException;
use AliyunMNS\Requests\BatchReceiveMessageRequest;
use AliyunMNS\Requests\BatchSendMessageRequest;

class CreateQueueAndSendMessage
{
    private $accessId = '';
    private $accessKey = '';
    private $endPoint = '';
    private $client;

    public function __construct()
    {
        $this->client = new Client($this->endPoint, $this->accessId, $this->accessKey);
    }

    /**
     * 创建消息队列
     * @param string $queueName 消息队列名称
     * @return mixed
     */
    public function createQueue($queueName)
    {
        $request = new CreateQueueRequest($queueName);
        $res = $this->client->createQueue($request);

        return $res->isSucceed() === true ? true : false;
    }

    /**
     * 发送消息
     * @param string $queueName 消息队列名称
     * @param string $message 发送的消息
     * @return mixed
     */
    public function sendMessage($queueName, $message)
    {
        $queue = $this->client->getQueueRef($queueName);
        $request = new SendMessageRequest($message);
        $result = $queue->sendMessage($request);

        return $result->isSucceed() === true ? true : false;
    }

    /**
     * 获取队列消息（不删除）
     * @param string $queueName 消息队列名称
     * @return mixed
     */
    public function receiveMessage($queueName)
    {
        $queue = $this->client->getQueueRef($queueName);
        $res = $queue->receiveMessage();

        return $res->isSucceed() === true ? $res->getMessageBody() : false;
    }

    /**
     * 获取队列消息并删除
     * @param string $queueName 消息队列名称
     * @return mixed
     */
    public function deleteMessage($queueName)
    {
        $queue = $this->client->getQueueRef($queueName);
        $res = $queue->receiveMessage(); // 获取队列里的消息
        if ($res->isSucceed() === true) {
            $receiptHandle = $res->getReceiptHandle();
            $queue->deleteMessage($receiptHandle); // 删除获取了的消息
            return $res->getMessageBody();
        } else {
            return false;
        }
    }

    /**
     * 删除一个队列
     * @param string $queueName 消息队列名称
     * @return mixed
     */
    public function deleteQueue($queueName)
    {
        $result = $this->client->deleteQueue($queueName);
        if ($result->isSucceed() === true) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 批量发送消息到指定的消息队列
     * @param string $queueName 队列名称
     * @param array $message 发送的消息数组(最多16个节点) ['item1', 'item2', 'item3']
     * @return bool
     */
    public function batchSendMessage($queueName, $message)
    {
        if (is_array($message) && $message && count($message) <= 16) {
            $queue = $this->client->getQueueRef($queueName);
            $request = new BatchSendMessageRequest($message);
            $result = $queue->batchSendMessage($request);

            return $result->isSucceed() === true ? true : false;
        }
        return false;
    }

    /**
     * 批量获取消息，最多16条
     * @param string $queueName
     * @return mixed
     */
    public function batchReceiveMessage($queueName)
    {
        $request = new BatchReceiveMessageRequest(16);

        $queue = $this->client->getQueueRef($queueName);
        $res = $queue->batchReceiveMessage($request);

        if ($res->isSucceed() === true) {
            $data = [];
            $receiptHandles = [];
            foreach ($res->getMessages() as $message) {
                $data[] = $message->getMessageBody();
                $receiptHandles[] = $message->getReceiptHandle();
            }
            $queue->batchDeleteMessage($receiptHandles);
            return $data;
        } else {
            return false;
        }
    }
    
}

echo '<pre>';
header('Content-Type:text/html;charset=utf-8');

$instance = new CreateQueueAndSendMessage();

// 发送消息入队列
$instance->sendMessage('demo22', '撒小12阿斯顿撒');

// 消费消息队列的消息并删除
$re = $instance->batchReceiveMessage('demo22');
var_dump($re);



/*$re = $instance->batchSendMessage('demo22', [
    '222222',
    '333333dasda',
]);
var_dump($re);*/




?>
